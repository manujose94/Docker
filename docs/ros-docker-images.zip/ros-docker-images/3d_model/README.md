A blend robot designer image based on BlenderRobotDesigner of the Neurorobotics Platform (NRP).
