#!/bin/bash
NAME_IMAGE=bobble_sim_container
NAME_CONTAINER=image_intel
matchingStartedID=$(sudo docker ps -aqf name=$NAME_IMAGE)

if [[ -n $matchingStartedID ]]; then	
	echo "$NAME_IMAGE alredy exist [ID: $matchingStartedID ]"
	echo "stop $NAME_IMAGE"
	docker stop $matchingStartedID	
else
echo "$NAME_IMAGE doesn't exist yet"
fi
