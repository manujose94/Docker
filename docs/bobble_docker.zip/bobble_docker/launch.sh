#!/bin/bash
#X server is a windowing system for bitmap displays, common on linux operating systems.
#The simple way is expose your xhost so that container can render to the correct display by reading and writing though the X11 unix socket.
# For further information in this regard: http://wiki.ros.org/docker/Tutorials/GUI
# 1. Before to launch this: xhost +local:root # for the lazy and reckless
# 2. After you are finished using the containerized GUI, this will return the access controls that were disabled with the previous command: xhost -local:root

NAME_IMAGE=bobble_sim_container
NAME_CONTAINER=image_intel
XAUTH=/tmp/.docker.xauth
if [ ! -f $XAUTH ]
then
    xauth_list=$(xauth nlist :0 | sed -e 's/^..../ffff/')
    if [ ! -z "$xauth_list" ]
    then
        echo $xauth_list | xauth -f $XAUTH nmerge -
    else
        touch $XAUTH
    fi
    chmod a+r $XAUTH
fi


matchingStartedID=$(sudo docker ps -aqf name=$NAME_IMAGE)

if [[ -n $matchingStartedID ]]; then
	docker stop $matchingStartedID		
	echo "$NAME_IMAGE alredy exist [ID: $matchingStartedID ]"
	echo "run $NAME_IMAGE"
	xhost +local:`docker inspect --format='{{ .Config.Hostname }}' $matchingStarted`
	docker start 3d8f59d9ee8f $matchingStarted
else
#Only first time 
xhost +local:root
#Run
docker run -it \
    --name=$NAME_IMAGE \
    --env="DISPLAY=$DISPLAY" \
    --env="QT_X11_NO_MITSHM=1" \
    --volume="/tmp/.X11-unix:/tmp/.X11-unix:rw" \
    --env="XAUTHORITY=$XAUTH" \
    --volume="$XAUTH:$XAUTH" \
    $NAME_CONTAINER  \
    roslaunch bobble_controllers run_sim.launch
fi
